# QR Code generator component

This directory contains a QR code generator component written in C. This component is based on [QR-Code-generator](https://github.com/nayuki/QR-Code-generator).

To learn more about how to use this component, please check API Documentation from header file [qrcode.h](./include/qrcode.h).
